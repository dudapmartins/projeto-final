// Rota para buscar o cardápio com base no ID do usuário
app.get('/cardapios/:userId', (req, res) => {
    const userId = req.params.userId;

    // Consulta SQL para buscar o cardápio do usuário
    const query = `
        SELECT * FROM cardapio
        WHERE user_id = ?
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Erro ao executar a consulta:', err);
            return res.status(500).json({ error: 'Erro ao buscar cardápio' });
        }

        // Se nenhum cardápio for encontrado
        if (results.length === 0) {
            return res.status(404).json({ message: 'Cardápio não encontrado' });
        }

        // Estrutura para retornar os dados no formato desejado
        const cardapio = {
            cafeDaManha: {
                opcao1: results[0].cafe_opcao1,
                opcao2: results[0].cafe_opcao2,
                opcao3: results[0].cafe_opcao3
            },
            almoco: {
                opcao1: results[0].almoco_opcao1,
                opcao2: results[0].almoco_opcao2,
                opcao3: results[0].almoco_opcao3
            },
            jantar: {
                opcao1: results[0].jantar_opcao1,
                opcao2: results[0].jantar_opcao2,
                opcao3: results[0].jantar_opcao3
            }
        };

        // Enviar a resposta com o cardápio
        res.json(cardapio);
    });
});

// Iniciar o servidor na porta 8080
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
